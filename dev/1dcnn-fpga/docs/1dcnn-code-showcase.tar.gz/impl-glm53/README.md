# impl-glm53 — 1D-CNN FPGA V1 (实施者 A / zcoder glm5.3)

Independent implementation under HANDOFF isolation.  
**Do not read or write `impl-deepseek/`.**

## What is here

| Path | Role |
| --- | --- |
| `include/regs.h` | Frozen AXI-Lite map (Phase1 arch §5.3) |
| `hls/` | Vitis HLS–style `cnn_engine` + csim tcl |
| `rtl/` | Frontend/glue stubs; top `system_1dcnn_pl` |
| `tb/` | Bit-exact C++ golden + harness |
| `vectors/` | ≥32 windows + `weights.bin` + per-case `.golden.bin` |
| `scripts/` | `weight_map.json`, weight/vector generators |
| `reports/` | bitexact / resource / csynth notes |
| `ps/` | mmap driver header + FR-09 `vote_alarm.c` |

## Tool versions on this box (2026-10-17 Asia/Shanghai)

| Tool | Status |
| --- | --- |
| g++ | 14.2.0 (Debian) — **used** |
| Python | 3.13.5 — **used** |
| make | GNU make — **used** |
| Vitis HLS / Vivado | **Not installed** — csynth N/A; sources + tcl provided |

## Quick start (software bit-exact)

```bash
cd /workspace/1dcnn-fpga/impl-glm53
make all          # weights + vectors + bitexact → reports/bitexact_result.md
make hls_csim_host
make vote_test
```

Expected: **32 / 32 PASS** for **DUT (`hls/cnn_engine`) ↔ golden (`tb/golden_cnn` → `*.golden.bin`)**, 0-bit.
Flow: `make gen_golden` then `make bitexact` (or `make all`).

## Weight layout

- Contract: `scripts/weight_map.json` (microarch §5.2).
- Export: `python3 scripts/gen_weights.py` → `vectors/weights.bin` (11504 INT16 words).
- Quant order: **MAC → scale/shift → saturate INT16 → ReLU** (FC: no ReLU).

## Register notes

- `REG_ID` reset documented as `0x1DCN0101` (letter **N** is not a hex digit).  
  Implemented as **`0x1DC00101`** (N→0). Flagged for principal if a different encoding was intended.
- `STATUS[5] feat_hotswap = 0` (V1).
- Scores via **`REG_SCORE0..9`**; AXIS: 10×INT16 beats, TLAST on last.
- `rst_n` active-low.

## V1 freeze compliance

- Throughput ≥2 win/s, 2048, HOP=LEN — satisfied by acquisition-bound math.
- Single weight bank + hot-swap stub (`ERR_CODE=0x20` if `bank_sel=1`).
- PACK_CH=0; XC7Z020 + AD7606-class stubs.
- BRAM estimate ≪ 70%.
- Latency estimate uses declared **`PE_M=16`**, **`PE_K_UNROLL=8`** (≈1275 μs @100 MHz under PE_M-only average) — **does not claim** 64-MAC/cycle; see `reports/resource_estimate.md`. NFR-02 throughput still OK (acquisition-bound).

## Doc ambiguities (not silently changed)

1. **REG_ID `0x1DCN0101`**: invalid C/Verilog hex → used `0x1DC00101`.
2. **Conv1 geometry**: shapes imply pad so Rout=512 with K=16,S=4 → **pad_left=pad_right=6**; Conv2/3 valid (documented in `weight_map.json`).
3. **Bias storage**: layout lists bias as INT16 words; MAC sign-extends to INT32 (matches §0.3 “bias INT32” at compute time).

## Non-goals (V1)

50% overlap throughput, dual-bank hot-swap function, thin-net / multi-engine, cloud stack, full FIR coefficient tuning.
