//==============================================================================
// adc_frontend — AD7606-class SPI stub + async FIFO interface (V1)
// CDC: clk_adc <-> clk_pl via async FIFO ports (external XPM/afifo instance)
// PACK_CH=0 default: 16-bit single-channel AXIS on clk_pl
//==============================================================================
`timescale 1ns/1ps
module adc_frontend #(
    parameter ADC_IF_TYPE = 0,  // 0=SPI
    parameter FIFO_DEPTH  = 256,
    parameter N_CH        = 2,
    parameter PACK_CH     = 0
)(
    input  wire        clk_adc,
    input  wire        rst_adc_n,
    input  wire        clk_pl,
    input  wire        rst_n,
    // SPI PHY
    output reg         adc_cs_n,
    output reg         adc_sclk,
    output reg         adc_mosi,
    input  wire        adc_miso,
    input  wire        adc_busy,
    output reg         adc_convst,
    // Config
    input  wire [1:0]  fs_sel,
    input  wire [1:0]  ch_sel,
    input  wire        capt_en,
    // Async FIFO write side (clk_adc)
    output reg  [31:0] fifo_wdata,
    output reg         fifo_wen,
    input  wire        fifo_full,
    input  wire        fifo_almost_full,
    // AXIS master (clk_pl) — driven by FIFO read adapter upstream
    output wire [15:0] m_axis_tdata,
    output wire        m_axis_tvalid,
    input  wire        m_axis_tready,
    output wire        m_axis_tlast,   // always 0 (no window TLAST)
    output wire [23:0] m_axis_tuser,
    // Status
    output reg         fifo_wr_err,
    output reg         ovfl_sticky
);
    localparam S_IDLE=0, S_WAIT_BUSY=1, S_READ_CH=2, S_WRITE_FIFO=3, S_ERROR=4;
    reg [2:0] state;
    reg [15:0] ch0_s, ch1_s;
    reg [7:0]  bit_cnt;
    reg [15:0] shift_in;

    assign m_axis_tdata  = 16'd0; // AXIS filled by separate afifo→axis adapter
    assign m_axis_tvalid = 1'b0;
    assign m_axis_tlast  = 1'b0;
    assign m_axis_tuser  = 24'd0;

    always @(posedge clk_adc or negedge rst_adc_n) begin
        if (!rst_adc_n) begin
            state <= S_IDLE;
            adc_cs_n <= 1'b1;
            adc_sclk <= 1'b0;
            adc_mosi <= 1'b0;
            adc_convst <= 1'b0;
            fifo_wen <= 1'b0;
            fifo_wdata <= 32'd0;
            fifo_wr_err <= 1'b0;
            ovfl_sticky <= 1'b0;
            bit_cnt <= 8'd0;
            ch0_s <= 16'd0;
            ch1_s <= 16'd0;
            shift_in <= 16'd0;
        end else begin
            fifo_wen <= 1'b0;
            adc_convst <= 1'b0;
            case (state)
                S_IDLE: begin
                    if (capt_en && !fifo_almost_full) begin
                        adc_convst <= 1'b1;
                        state <= S_WAIT_BUSY;
                    end else if (capt_en && fifo_almost_full) begin
                        ovfl_sticky <= 1'b1;
                        fifo_wr_err <= 1'b1;
                        state <= S_ERROR;
                    end
                end
                S_WAIT_BUSY: begin
                    if (adc_busy) state <= S_READ_CH;
                    bit_cnt <= 8'd0;
                    adc_cs_n <= 1'b0;
                end
                S_READ_CH: begin
                    // Simplified SPI: 32 clocks for 2x16b (stub)
                    adc_sclk <= ~adc_sclk;
                    if (adc_sclk) begin
                        shift_in <= {shift_in[14:0], adc_miso};
                        bit_cnt <= bit_cnt + 8'd1;
                        if (bit_cnt == 8'd15) ch0_s <= {shift_in[14:0], adc_miso};
                        if (bit_cnt == 8'd31) begin
                            ch1_s <= {shift_in[14:0], adc_miso};
                            state <= S_WRITE_FIFO;
                            adc_cs_n <= 1'b1;
                        end
                    end
                end
                S_WRITE_FIFO: begin
                    if (!fifo_full) begin
                        fifo_wdata <= {ch1_s, ch0_s};
                        fifo_wen <= 1'b1;
                        state <= S_IDLE;
                    end else begin
                        ovfl_sticky <= 1'b1;
                        fifo_wr_err <= 1'b1;
                        state <= S_ERROR;
                    end
                end
                S_ERROR: begin
                    if (!capt_en) begin
                        fifo_wr_err <= 1'b0;
                        state <= S_IDLE;
                    end
                end
                default: state <= S_IDLE;
            endcase
        end
    end
endmodule
