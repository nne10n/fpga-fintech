//==============================================================================
// score_path — capture 10-beat INT16 AXIS scores into REG_SCORE0..9 snapshot
// TLAST on last beat; irq pulse ≥2 clk when irq_en
//==============================================================================
`timescale 1ns/1ps
module score_path #(
    parameter N_CLASS = 10
)(
    input  wire        clk_pl,
    input  wire        rst_n,
    input  wire [15:0] s_axis_tdata,
    input  wire        s_axis_tvalid,
    output wire        s_axis_tready,
    input  wire        s_axis_tlast,
    input  wire        irq_en,
    output reg  [31:0] score_regs [0:9],
    output reg         done_pulse,
    output reg         irq_pulse
);
    assign s_axis_tready = 1'b1;
    reg [3:0] idx;
    reg [1:0] irq_cnt;
    localparam S_WAIT=0, S_CAP=1, S_IRQ=2;
    reg [1:0] state;

    always @(posedge clk_pl or negedge rst_n) begin
        if (!rst_n) begin
            idx <= 0;
            done_pulse <= 0;
            irq_pulse <= 0;
            irq_cnt <= 0;
            state <= S_WAIT;
            for (integer i = 0; i < 10; i++) score_regs[i] <= 32'd0;
        end else begin
            done_pulse <= 1'b0;
            case (state)
                S_WAIT: begin
                    irq_pulse <= 1'b0;
                    if (s_axis_tvalid) begin
                        score_regs[0] <= {{16{s_axis_tdata[15]}}, s_axis_tdata};
                        idx <= 4'd1;
                        state <= S_CAP;
                        if (s_axis_tlast) begin
                            done_pulse <= 1'b1;
                            state <= irq_en ? S_IRQ : S_WAIT;
                            irq_cnt <= 2'd2;
                        end
                    end
                end
                S_CAP: begin
                    if (s_axis_tvalid) begin
                        score_regs[idx] <= {{16{s_axis_tdata[15]}}, s_axis_tdata};
                        if (s_axis_tlast || idx == 4'd9) begin
                            done_pulse <= 1'b1;
                            state <= irq_en ? S_IRQ : S_WAIT;
                            irq_cnt <= 2'd2;
                            idx <= 0;
                        end else idx <= idx + 4'd1;
                    end
                end
                S_IRQ: begin
                    irq_pulse <= 1'b1;
                    if (irq_cnt == 2'd0) begin
                        irq_pulse <= 1'b0;
                        state <= S_WAIT;
                    end else irq_cnt <= irq_cnt - 2'd1;
                end
                default: state <= S_WAIT;
            endcase
        end
    end
endmodule
