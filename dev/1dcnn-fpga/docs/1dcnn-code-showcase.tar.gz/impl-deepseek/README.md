# 1D-CNN FPGA V1 — Implementer B (`impl-deepseek`)

Isolated delivery for XC7Z020 + AD7606-class, Vitis HLS INT16 path.
**Top module:** `system_1dcnn_pl` (`rtl/system_1dcnn_pl.sv`).

Read-only baseline: `/workspace/1dcnn-fpga/docs/` (HANDOFF > Phase0 > Phase1 microarch > Phase1 arch).
**Do not read/write `../impl-glm53/`.**

## Tool versions (host box)

| Tool | Version / note |
| --- | --- |
| g++ | C++17 (host csim) |
| python3 | 3.x + numpy |
| Vitis HLS | **not required** for `make csim`; use when available for csynth |
| Vivado | for RTL integrate / bitstream (later Phase) |

## Quick start — host csim (bit-exact)

```bash
cd /workspace/1dcnn-fpga/impl-deepseek
./scripts/run_csim.sh
# or: make csim
```

Exit 0 ⇒ ≥32 vectors pass 0-bit score match vs `ref/fixed_point_cnn.py`.
Report: `reports/bitexact_result.md`.

### Regenerate weights / vectors

```bash
python3 scripts/export_weight_map.py   # → vectors/weight_map.json
python3 scripts/gen_vectors.py         # ≥32 cases + weights_synthetic.bin
```

Synthetic weight seed **42**; vector seed **20261017**. Replace blob via same `weight_map.json` layout after training export.

## V1 freezes (summary)

- WIN=2048, HOP=LEN (no overlap), ≥2 win/s
- INT16 act/wgt + INT32 acc; quant: MAC→scale/shift→sat i16→ReLU
- Single weight bank; `STATUS[5]=feat_hotswap=0`; `WEIGHT_CTRL[1]=bank_sel` reserved
- Scores: 10 beats INT16, TLAST on last; `REG_SCORE0..9` @ 0x080–0x0A4
- `REG_ID` doc mnemonic `0x1DCN0101` → encoded `0x1DC00101` (N→0 valid hex)
- `rst_n` active-low; default `PACK_CH=0`

## Tree

```
impl-deepseek/
├── README.md
├── Makefile
├── include/regs.h
├── hls/          # cnn_engine + FIR/window/weight stubs + run_hls.tcl
├── rtl/          # adc_frontend, axi_ctrl, score_path, system_1dcnn_pl
├── tb/csim_main.cpp
├── ref/fixed_point_cnn.py
├── scripts/      # export_weight_map.py, gen_vectors.py, run_csim.sh
├── vectors/      # weight_map.json, cases/, weights_synthetic.bin
├── reports/      # hls_csynth_summary, resource_estimate, bitexact_result
└── ps/           # driver mmap/UIO + vote_alarm.c (FR-09)
```

## When Vitis HLS is available

```bash
cd hls
vitis_hls -f run_hls.tcl
# part xc7z020clg400-1, clock 6.67 ns (150 MHz) — also try 10 ns (100 MHz)
```

Then integrate exported IP with `rtl/system_1dcnn_pl.sv` in Vivado BD.

## Baseline network

| Layer | Config | Out |
| --- | --- | --- |
| Conv1 | k=16,c=16,s=4,pad=12 | 512×16 |
| Conv2 | k=8,c=32,s=4,valid | 127×32 |
| Pool | k=2,s=2 | 63×32 |
| Conv3 | k=3,c=64,s=1,valid | 61×64 |
| GAP | recip mult/shift | 64 |
| FC | 64→10 | 10 |

Weight words total: **11504** (~23 KB) per `vectors/weight_map.json`.
